/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.bean;

/**
 *
 * @author Leonardo
 */
public class ClientePedido {
    private int id;
    private int idCli;
    private int idPed;
    private String obs;
    private Cliente cli;
    private Pedido ped;

    public ClientePedido(int id, int idCli, int idPed, String obs) {
        this.id = id;
        this.idCli = idCli;
        this.idPed = idPed;
        this.obs = obs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdCli() {
        return idCli;
    }

    public void setIdCli(int idCli) {
        this.idCli = idCli;
    }

    public int getIdPed() {
        return idPed;
    }

    public void setIdPed(int idPed) {
        this.idPed = idPed;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public Cliente getCli() {
        return cli;
    }

    public void setCli(Cliente cli) {
        this.cli = cli;
    }

    public Pedido getPed() {
        return ped;
    }

    public void setPed(Pedido ped) {
        this.ped = ped;
    }

   
    @Override
    public String toString() {
        return "ClientePedido{" + "id=" + id + ", idCli=" + idCli + ", idPed=" + idPed + ", obs=" + obs + ", c=" + cli.getNome() + ", p=" + ped.getNome() + '}';
    }
    
    
}
