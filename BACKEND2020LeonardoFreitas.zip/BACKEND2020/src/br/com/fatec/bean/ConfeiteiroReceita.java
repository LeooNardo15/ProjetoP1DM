/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.bean;

/**
 *
 * @author Leonardo
 */
public class ConfeiteiroReceita {
    private int id;
    private int idConf;
    private int idRec;
    private String obs;
    private Confeiteiros conf;
    private Pedido rec;

    public ConfeiteiroReceita(int id, int idConf, int idRec, String obs) {
        this.id = id;
        this.idConf = idConf;
        this.idRec = idRec;
        this.obs = obs;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdConf() {
        return idConf;
    }

    public void setIdConf(int idConf) {
        this.idConf = idConf;
    }

    public int getIdRec() {
        return idRec;
    }

    public void setIdRec(int idRec) {
        this.idRec = idRec;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public Confeiteiros getConf() {
        return conf;
    }

    public void setConf(Confeiteiros conf) {
        this.conf = conf;
    }

    public Pedido getRec() {
        return rec;
    }

    public void setRec(Pedido rec) {
        this.rec = rec;
    }

    @Override
    public String toString() {
        return "ConfeiteiroReceita{" + "id=" + id + ", idConf=" + idConf + ", idRec=" + idRec + ", obs=" + obs + ", conf=" + conf.getNome() + ", rec=" + rec.getNome() + '}';
    }
    
    
}
