/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.bean;

/**
 *
 * @author Leonardo
 */
public class Confeiteiros {
    private int id;
    private String nome;
    private String telefone;
    private String cpf;

    public Confeiteiros(int id, String nome, String telefone, String cpf) {
        this.nome = nome;
        this.id = id;
        this.telefone = telefone;
        this.cpf = cpf;
    }

    public Confeiteiros(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    @Override
    public String toString() {
        return "Confeiteiros{" + "nome=" + nome + ", id=" + id + ", telefone=" + telefone + ", cpf=" + cpf + '}';
    }
    
    
}
