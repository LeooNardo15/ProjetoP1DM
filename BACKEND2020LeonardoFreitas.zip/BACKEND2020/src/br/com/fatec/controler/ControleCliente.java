/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.controler;

import br.com.fatec.bean.Cliente;
import br.com.fatec.db.DaoCliente;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class ControleCliente {
     public static DaoCliente daoCli;

    public Cliente buscaClientePorId (Cliente cli) throws SQLException, ClassNotFoundException {
        daoCli = new DaoCliente();
        return daoCli.busca(cli);
    }

    public Cliente inseriCliente (Cliente cli) throws SQLException, ClassNotFoundException {
        daoCli = new DaoCliente();
        return daoCli.inseri(cli);
    }

    public Cliente alteraCliente (Cliente cli) throws SQLException, ClassNotFoundException {
        daoCli = new DaoCliente();
        return daoCli.altera(cli);
    }

    public Cliente excluiCliente (Cliente cli) throws SQLException, ClassNotFoundException {
        daoCli = new DaoCliente();
        return daoCli.exclui(cli);
    }

    public List<Cliente> listaCliente (Cliente cli) throws SQLException, ClassNotFoundException {
        List<Cliente> listCli = new ArrayList();
        daoCli = new DaoCliente();
        listCli = daoCli.lista(cli);
        return listCli;
    }
    
    public List<Cliente> listarTodosCliente() throws SQLException, ClassNotFoundException {
        List<Cliente>  clis ;
        DaoCliente cliDao = new DaoCliente();
        clis = cliDao.listaTodos();
        return clis;
        
    }
    
    public Cliente buscarCliente(Cliente cli) throws SQLException, ClassNotFoundException {
        DaoCliente cliDao = new DaoCliente();
        cli = cliDao.busca(cli);
        return cli;
    }
}

