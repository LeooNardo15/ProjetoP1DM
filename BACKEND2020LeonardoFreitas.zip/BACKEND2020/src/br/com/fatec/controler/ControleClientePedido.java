/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.controler;

import br.com.fatec.bean.Cliente;
import br.com.fatec.bean.ClientePedido;
import br.com.fatec.bean.Pedido;
import br.com.fatec.db.DaoClientePedido;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class ControleClientePedido {
    public static ControleCliente contCli;
    public static ControlePedido  contPed;
    public static DaoClientePedido daoCliPed;
    
    public ClientePedido inserirClientePedido(ClientePedido cliPed) throws SQLException, ClassNotFoundException {
        daoCliPed = new DaoClientePedido();
        return daoCliPed.inseri(cliPed);
    }
 
    public ClientePedido excluirClientePedido(ClientePedido cliPed) throws SQLException, ClassNotFoundException {
        daoCliPed = new DaoClientePedido();
        return daoCliPed.exclui(cliPed);
    }

    public ClientePedido alterarClientePedido(ClientePedido cliPed) throws SQLException, ClassNotFoundException {
        daoCliPed = new DaoClientePedido();
        return daoCliPed.altera(cliPed);
    }

    public ClientePedido buscarClientePedidoPorId(ClientePedido cliPed) throws SQLException, ClassNotFoundException {

        daoCliPed = new DaoClientePedido();
        cliPed = daoCliPed.busca(cliPed);
        
        contCli = new ControleCliente();
        contPed = new ControlePedido();

        Cliente cli = new Cliente(cliPed.getIdCli(),"", "");
        Pedido ped = new Pedido(cliPed.getIdPed(),"");
        
        cliPed.setCli(contCli.buscaClientePorId(cli));
        cliPed.setPed(contPed.buscaPedidoPorId(ped));

        return cliPed;
    }


    public List<ClientePedido> listarClientePedido(ClientePedido cliPed) throws SQLException, ClassNotFoundException {

        contPed = new ControlePedido();
        contCli = new ControleCliente();

        daoCliPed = new DaoClientePedido();
        List<ClientePedido> cliPedi = daoCliPed.lista(cliPed);

        for (ClientePedido listaCP : cliPedi) {
            Cliente cli = new Cliente(listaCP.getIdCli(),"");
            Pedido ped = new Pedido(listaCP.getIdPed(),"");
            listaCP.setCli(contCli.buscaClientePorId(cli));
            listaCP.setPed(contPed.buscaPedidoPorId(ped));
        }

        return cliPedi;
    }

}
