/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.controler;

import br.com.fatec.bean.Cliente;
import br.com.fatec.bean.Confeiteiros;
import br.com.fatec.db.DaoCliente;
import br.com.fatec.db.DaoConfeiteiros;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class ControleConfeiteiro {
    public static DaoConfeiteiros daoConf;

    public Confeiteiros buscaConfeiteiroPorId (Confeiteiros conf) throws SQLException, ClassNotFoundException {
        daoConf = new DaoConfeiteiros();
        return daoConf.busca(conf);
    }

    public Confeiteiros inseriConfeiteiro (Confeiteiros conf) throws SQLException, ClassNotFoundException {
        daoConf = new DaoConfeiteiros();
        return daoConf.inseri(conf);
    }

    public Confeiteiros alteraConfeiteiro (Confeiteiros conf) throws SQLException, ClassNotFoundException {
        daoConf = new DaoConfeiteiros();
        return daoConf.altera(conf);
    }

    public Confeiteiros excluiConfeiteiro (Confeiteiros conf) throws SQLException, ClassNotFoundException {
        daoConf = new DaoConfeiteiros();
        return daoConf.exclui(conf);
    }

    public List<Confeiteiros> listaConfeiteiros (Confeiteiros conf) throws SQLException, ClassNotFoundException {
        List<Confeiteiros> listConf = new ArrayList();
        daoConf = new DaoConfeiteiros();
        listConf = daoConf.lista(conf);
        return listConf;
    }
    
    public List<Confeiteiros> listarTodosConfeiteiro() throws SQLException, ClassNotFoundException {
        List<Confeiteiros>  confs ;
        DaoConfeiteiros confDao = new DaoConfeiteiros();
        confs = confDao.listaTodos();
        return confs;
        
    }
    
    public Confeiteiros buscarConfeiteiro(Confeiteiros conf) throws SQLException, ClassNotFoundException {
        DaoConfeiteiros confDao = new DaoConfeiteiros();
        conf = confDao.busca(conf);
        return conf;
    }
}
