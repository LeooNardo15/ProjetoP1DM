/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.controler;

import br.com.fatec.bean.ConfeiteiroReceita;
import br.com.fatec.bean.Confeiteiros;
import br.com.fatec.bean.Pedido;
import br.com.fatec.db.DaoConfeiteiroReceita;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class ControleConfeiteiroReceita {
    public static ControleConfeiteiro contConf;
    public static ControlePedido  contRec;
    public static DaoConfeiteiroReceita daoConfRec;
    
    public ConfeiteiroReceita inserirConfeiteiroReceita(ConfeiteiroReceita confRec) throws SQLException, ClassNotFoundException {
        daoConfRec = new DaoConfeiteiroReceita();
        return daoConfRec.inseri(confRec);
    }
 
    public ConfeiteiroReceita excluirConfeiteiroReceita(ConfeiteiroReceita confRec) throws SQLException, ClassNotFoundException {
        daoConfRec = new DaoConfeiteiroReceita();
        return daoConfRec.exclui(confRec);
    }

    public ConfeiteiroReceita alterarConfeiteiroReceita(ConfeiteiroReceita confRec) throws SQLException, ClassNotFoundException {
        daoConfRec = new DaoConfeiteiroReceita();
        return daoConfRec.altera(confRec);
    }

    public ConfeiteiroReceita buscarConfeiteiroReceitaPorId(ConfeiteiroReceita confRec) throws SQLException, ClassNotFoundException {

        daoConfRec = new DaoConfeiteiroReceita();
        confRec = daoConfRec.busca(confRec);
        
        contConf = new ControleConfeiteiro();
        contRec = new ControlePedido();

        Confeiteiros conf = new Confeiteiros(confRec.getIdConf(),"", "", "");
        Pedido rec = new Pedido(confRec.getIdRec(),"", "");
        
        confRec.setConf(contConf.buscaConfeiteiroPorId(conf));
        confRec.setRec(contRec.buscaPedidoPorId(rec));

        return confRec;
    }


    public List<ConfeiteiroReceita> listarConfeiteiroReceita(ConfeiteiroReceita confRec) throws SQLException, ClassNotFoundException {

        contRec = new ControlePedido();
        contConf = new ControleConfeiteiro();

        daoConfRec = new DaoConfeiteiroReceita();
        List<ConfeiteiroReceita> confReci = daoConfRec.lista(confRec);

        for (ConfeiteiroReceita listaCP : confReci) {
            Confeiteiros conf = new Confeiteiros(listaCP.getIdConf(),"");
            Pedido rec = new Pedido(listaCP.getIdRec(),"");
            listaCP.setConf(contConf.buscaConfeiteiroPorId(conf));
            listaCP.setRec(contRec.buscaPedidoPorId(rec));
        }

        return confReci;
    }
}
