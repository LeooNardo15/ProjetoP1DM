/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.controler;

import br.com.fatec.bean.Confeiteiros;
import br.com.fatec.bean.Pedido;
import br.com.fatec.db.DaoConfeiteiros;
import br.com.fatec.db.DaoPedido;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class ControlePedido {
    public static DaoPedido daoPed;

    public Pedido buscaPedidoPorId (Pedido ped) throws SQLException, ClassNotFoundException {
        daoPed = new DaoPedido();
        return daoPed.busca(ped);
    }

    public Pedido inseriPedido (Pedido ped) throws SQLException, ClassNotFoundException {
        daoPed = new DaoPedido();
        return daoPed.inseri(ped);
    }

    public Pedido alteraPedido (Pedido ped) throws SQLException, ClassNotFoundException {
        daoPed = new DaoPedido();
        return daoPed.altera(ped);
    }

    public Pedido excluiPedido (Pedido ped) throws SQLException, ClassNotFoundException {
        daoPed = new DaoPedido();
        return daoPed.exclui(ped);
    }

    public List<Pedido> listaPedido (Pedido ped) throws SQLException, ClassNotFoundException {
        List<Pedido> listPed = new ArrayList();
        daoPed = new DaoPedido();
        listPed = daoPed.lista(ped);
        return listPed;
    }
    
    public List<Pedido> listarTodosPedido() throws SQLException, ClassNotFoundException {
        List<Pedido>  peds ;
        DaoPedido pedDao = new DaoPedido();
        peds = pedDao.listaTodos();
        return peds;
        
    }
    
    public Pedido buscarPedido(Pedido ped) throws SQLException, ClassNotFoundException {
        DaoPedido pedDao = new DaoPedido();
        ped = pedDao.busca(ped);
        return ped;
    }
}
