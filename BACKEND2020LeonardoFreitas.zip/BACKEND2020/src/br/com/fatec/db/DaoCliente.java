/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.db;

import br.com.fatec.bean.Cliente;
import br.com.fatec.util.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class DaoCliente {
    private final Connection c;
    
    public DaoCliente() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    
    
    public Cliente busca(Cliente cli) throws SQLException{
        String sql = "select * from cliente WHERE cli_id = ?";
        
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,cli.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                // criando o objeto Usuario
                cli.setId(rs.getInt(1));
                cli.setNome(rs.getString(2));
                cli.setTelefone(rs.getString(3));
                // adiciona o usu à lista de usus
            }

            stmt.close();
            c.close();
    
        return cli;

    }
    
    public Cliente altera(Cliente cli) throws SQLException{
        String sql = "UPDATE cliente SET cli_nome = ?, cli_telefone = ? WHERE cli_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,cli.getNome());
        stmt.setString(2,cli.getTelefone());
        stmt.setInt(3,cli.getId());

        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return cli;
    }

    public Cliente exclui(Cliente cli) throws SQLException{
        String sql = "delete from cliente WHERE cli_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,cli.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return cli;
    }
    
    
    public Cliente inseri(Cliente cli) throws SQLException{
        String sql = "insert into cliente" + " (cli_nome, cli_telefone)" + " values (?,?)";
    
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setString(1,cli.getNome());
        stmt.setString(2,cli.getTelefone());
        // executa
        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            cli.setId(id);
        }
        stmt.close();
        c.close();
        return cli;
    }

    public List<Cliente> lista(Cliente cliEnt) throws SQLException{
         // usus: array armazena a lista de registros

        List<Cliente> cli = new ArrayList<>();
        
        String sql = "select * from cliente where cli_nome like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + cliEnt.getNome() + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto cliente
            Cliente cl = new Cliente(rs.getInt(1),rs.getString(2),rs.getString(3));
            // adiciona o usu à lista de logs
            cli.add(cl);
        }
        
        rs.close();
        stmt.close();
        return cli;
        
    }
    
    public List<Cliente> listaTodos() throws SQLException{
         // usus: array armazena a lista de registros

        List<Cliente> clis = new ArrayList<Cliente>();
        
        String sql = "select * from cliente";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Cliente cli = new Cliente(
                rs.getInt(1),
                rs.getString(2),
                rs.getString(3)                
            );
            // adiciona o usu à lista de usus
            clis.add(cli);
        }
        
        rs.close();
        stmt.close();
        return clis;
        
    }
}
