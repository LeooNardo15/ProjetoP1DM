/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.db;

import br.com.fatec.bean.ClientePedido;
import br.com.fatec.util.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class DaoClientePedido {
    private final Connection c;
    
    public DaoClientePedido() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    
    public ClientePedido altera(ClientePedido cp) throws SQLException{
        String sql = "UPDATE cp_cliente_pedido SET cp_cli_id = ?, cp_ped_id = ?, cp_obs = ? WHERE cp_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,cp.getIdCli());
        stmt.setInt(2,cp.getIdPed());
        stmt.setString(3,cp.getObs());
        stmt.setInt(4,cp.getId());

        // executa
        stmt.execute();
        stmt.close();
        return cp;
    }

    public ClientePedido exclui(ClientePedido cp) throws SQLException{
        String sql = "delete from cp_cliente_pedido WHERE cp_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,cp.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return cp;
    }


    public ClientePedido inseri(ClientePedido cp) throws SQLException{
        String sql = "insert into cp_cliente_pedido" + " (cp_cli_id, cp_ped_id, cp_obs)" + " values (?,?,?)";
    
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setInt(1,cp.getIdCli());
        stmt.setInt(2,cp.getIdPed());
        stmt.setString(3,cp.getObs());

        // executa
        stmt.execute();
        stmt.close();
        return cp;
    }
    
    public ClientePedido busca(ClientePedido cp) throws SQLException{
        String sql = "select * from cp_cliente_pedido WHERE cp_id = ?";
        
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,cp.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                // criando o objeto Usuario
                cp.setId(rs.getInt(1));
                cp.setIdCli(rs.getInt(2));
                cp.setIdPed(rs.getInt(3));
                cp.setObs(rs.getString(4));
                // adiciona o usu à lista de usus
            }
        return cp;
    }
    
    public List<ClientePedido> lista(ClientePedido cp) throws SQLException{

        List<ClientePedido> cped = new ArrayList<>();
        
        String sql = "select * from cp_cliente_pedido where cp_obs like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + cp.getObs()+ "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            ClientePedido cpe = new ClientePedido(
                rs.getInt(1),
                rs.getInt(2),
                rs.getInt(3),
                rs.getString(4)
            );
            // adiciona o usu à lista de usus
            cped.add(cpe);
        }
        
        rs.close();
        stmt.close();
        return cped;
    }
}
