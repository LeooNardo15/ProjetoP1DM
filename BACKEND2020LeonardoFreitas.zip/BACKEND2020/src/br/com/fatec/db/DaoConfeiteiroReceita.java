/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.db;

import br.com.fatec.bean.ConfeiteiroReceita;
import br.com.fatec.util.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class DaoConfeiteiroReceita {
    private final Connection c;
    
    public DaoConfeiteiroReceita() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    
    public ConfeiteiroReceita altera(ConfeiteiroReceita cr) throws SQLException{
        String sql = "UPDATE cr_confeiteiro_receita SET cr_conf_id = ?, cr_rec_id = ?, cr_obs = ? WHERE cr_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,cr.getIdConf());
        stmt.setInt(2,cr.getIdRec());
        stmt.setString(3,cr.getObs());
        stmt.setInt(4,cr.getId());

        // executa
        stmt.execute();
        stmt.close();
        return cr;
    }

    public ConfeiteiroReceita exclui(ConfeiteiroReceita cr) throws SQLException{
        String sql = "delete from cr_confeiteiro_receita WHERE cr_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,cr.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return cr;
    }


    public ConfeiteiroReceita inseri(ConfeiteiroReceita cr) throws SQLException{
        String sql = "insert into cr_confeiteiro_receita" + " (cr_conf_id, cr_rec_id, cr_obs)" + " values (?,?,?)";
    
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setInt(1,cr.getIdConf());
        stmt.setInt(2,cr.getIdRec());
        stmt.setString(3,cr.getObs());

        // executa
        stmt.execute();
        stmt.close();
        return cr;
    }
    
    public ConfeiteiroReceita busca(ConfeiteiroReceita cr) throws SQLException{
        String sql = "select * from cr_confeiteiro_receita WHERE cr_id = ?";
        
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,cr.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                // criando o objeto Usuario
                cr.setId(rs.getInt(1));
                cr.setIdConf(rs.getInt(2));
                cr.setIdRec(rs.getInt(3));
                cr.setObs(rs.getString(4));
                // adiciona o usu à lista de usus
            }
        return cr;
    }
    
    public List<ConfeiteiroReceita> lista(ConfeiteiroReceita cr) throws SQLException{

        List<ConfeiteiroReceita> crec = new ArrayList<>();
        
        String sql = "select * from cr_confeiteiro_receita where cr_obs like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + cr.getObs()+ "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            ConfeiteiroReceita cre = new ConfeiteiroReceita(
                rs.getInt(1),
                rs.getInt(2),
                rs.getInt(3),
                rs.getString(4)
            );
            // adiciona o usu à lista de usus
            crec.add(cre);
        }
        
        rs.close();
        stmt.close();
        return crec;
    }
}
