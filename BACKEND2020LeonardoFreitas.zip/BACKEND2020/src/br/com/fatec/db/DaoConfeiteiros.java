/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.db;

import br.com.fatec.bean.Confeiteiros;
import br.com.fatec.util.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class DaoConfeiteiros {
    private final Connection c;
    
    public DaoConfeiteiros() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    
    
    public Confeiteiros busca(Confeiteiros conf) throws SQLException{
        String sql = "select * from confeiteiros WHERE conf_id = ?";
        
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,conf.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                // criando o objeto Usuario
                conf.setId(rs.getInt(1));
                conf.setNome(rs.getString(2));
                conf.setTelefone(rs.getString(3));
                conf.setCpf(rs.getString(4));
                // adiciona o usu à lista de usus
            }

            stmt.close();
            c.close();
    
        return conf;

    }
    
    public Confeiteiros altera(Confeiteiros conf) throws SQLException{
        String sql = "UPDATE confeiteiros SET conf_nome = ?, conf_cpf = ?, conf_telefone = ? WHERE conf_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
            stmt.setString(1, conf.getNome());
            stmt.setString(2, conf.getCpf());
            stmt.setString(3, conf.getTelefone());
            stmt.setInt(4, conf.getId());

        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return conf;
    }

    public Confeiteiros exclui(Confeiteiros conf) throws SQLException{
        String sql = "delete from confeiteiros WHERE conf_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,conf.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return conf;
    }
    
    
    public Confeiteiros inseri(Confeiteiros conf) throws SQLException{
        String sql = "insert into confeiteiros" + " (conf_nome, conf_cpf, conf_telefone)" + " values (?,?,?)";
    
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setString(1,conf.getNome());
        stmt.setString(2,conf.getTelefone());
        stmt.setString(3,conf.getCpf());

        // executa
        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            conf.setId(id);
        }
        stmt.close();
        c.close();
        return conf;
    }

    public List<Confeiteiros> lista(Confeiteiros confEnt) throws SQLException{
         // usus: array armazena a lista de registros

            List<Confeiteiros> conf = new ArrayList<>();
        
        String sql = "select * from confeiteiros where conf_nome like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + confEnt.getNome() + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            Confeiteiros con = new Confeiteiros(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
            conf.add(con);
        }
        
        rs.close();
        stmt.close();
        return conf;
        
    }
    
    public List<Confeiteiros> listaTodos() throws SQLException{
         // usus: array armazena a lista de registros

        List<Confeiteiros> confs = new ArrayList<Confeiteiros>();
        
        String sql = "select * from confeiteiros";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Confeiteiros conf = new Confeiteiros(
                rs.getInt(1),
                rs.getString(2),
                rs.getString(3),
                rs.getString(4)
            );
            // adiciona o usu à lista de usus
            confs.add(conf);
        }
        
        rs.close();
        stmt.close();
        return confs;
        
    }
}
