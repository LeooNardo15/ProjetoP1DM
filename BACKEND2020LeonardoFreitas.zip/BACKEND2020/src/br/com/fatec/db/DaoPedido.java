/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.db;

import br.com.fatec.bean.Pedido;
import br.com.fatec.util.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo
 */
public class DaoPedido {
    private final Connection c;
    
    public DaoPedido() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    
    
    public Pedido busca(Pedido ped) throws SQLException{
        String sql = "select * from pedido WHERE ped_id = ?";
        
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,ped.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                // criando o objeto Usuario
                ped.setId(rs.getInt(1));
                ped.setNome(rs.getString(2));
                ped.setPreco(rs.getString(3));
                // adiciona o usu à lista de usus
            }

            stmt.close();
            c.close();
    
        return ped;

    }
    
    public Pedido altera(Pedido ped) throws SQLException{
        String sql = "UPDATE pedido SET ped_nome = ?, ped_preco = ? WHERE ped_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,ped.getNome());
        stmt.setString(2,ped.getPreco());
        stmt.setInt(3,ped.getId());

        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return ped;
    }

    public Pedido exclui(Pedido ped) throws SQLException{
        String sql = "delete from pedido WHERE ped_id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,ped.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return ped;
    }
    
    
    public Pedido inseri(Pedido ped) throws SQLException{
        String sql = "insert into pedido" + " (ped_id, ped_nome, ped_preco)" + " values (?,?,?)";
    
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setInt(1,ped.getId());
        stmt.setString(2,ped.getNome());
        stmt.setString(3,ped.getPreco());

        // executa
        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            ped.setId(id);
        }
        stmt.close();
        c.close();
        return ped;
    }

    public List<Pedido> lista(Pedido pedEnt) throws SQLException{
         // usus: array armazena a lista de registros

        List<Pedido> ped = new ArrayList<>();
        
        String sql = "select * from pedido where ped_nome like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + pedEnt.getNome() + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Logradouro
            Pedido pe = new Pedido(rs.getInt(1), rs.getString(2),rs.getString(3));
            // adiciona o usu à lista de logs
            ped.add(pe);
        }
        
        rs.close();
        stmt.close();
        return ped;
        
    }
    
        public List<Pedido> listaTodos() throws SQLException{
         // usus: array armazena a lista de registros

        List<Pedido> peds = new ArrayList<Pedido>();
        
        String sql = "select * from pedido";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Pedido ped = new Pedido(
                rs.getInt(1),
                rs.getString(2),
                rs.getString(3)
            );
            // adiciona o usu à lista de usus
            peds.add(ped);
        }
        
        rs.close();
        stmt.close();
        return peds;
        
    }
}
