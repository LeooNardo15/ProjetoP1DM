/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.controler;

import br.com.fatec.bean.ClientePedido;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Leonardo
 */
public class TesteControlerClientePedido {
    public TesteControlerClientePedido() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

@Test
    public void inserir() throws SQLException, ClassNotFoundException {
          ClientePedido cliPed = new ClientePedido(0,1,1,"TESTE RELACAO");
          ControleClientePedido contCliPed = new ControleClientePedido();
          cliPed = contCliPed.inserirClientePedido(cliPed);
          assertEquals(0, cliPed.getId());
    }

    @Test
    public void busca() throws SQLException, ClassNotFoundException {
          ClientePedido cliPed = new ClientePedido(1,0,0,"");
          ControleClientePedido contFunDep = new ControleClientePedido();
          cliPed = contFunDep.buscarClientePedidoPorId(cliPed);
          
          System.out.println("IMPRESSAO TESTE DE BUSCA " + cliPed.toString());
          
          assertEquals(1, cliPed.getId());
    }

    
    @Test
    public void lista() throws SQLException, ClassNotFoundException {
          ClientePedido cliPed = new ClientePedido(0,0,0,"RELACAO");
          ControleClientePedido contCliPed = new ControleClientePedido();
          List<ClientePedido> listaCP = new ArrayList();
          listaCP = contCliPed.listarClientePedido(cliPed);

          System.out.println("IMPRESSAO TESTE DE LISTA " + listaCP.get(0).toString());


          assertEquals(1, listaCP.get(0).getId());
    }

    
}

