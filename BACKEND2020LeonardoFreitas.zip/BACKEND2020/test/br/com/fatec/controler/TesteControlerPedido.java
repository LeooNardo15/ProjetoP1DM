/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.controler;

import br.com.fatec.bean.Pedido;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Leonardo
 */
public class TesteControlerPedido {
    public TesteControlerPedido() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

    @Test
    public void inserir() throws SQLException, ClassNotFoundException {
          Pedido ped = new Pedido(0,"Bolo", "");
          ControlePedido contPed = new ControlePedido();
          ped = contPed.inseriPedido(ped);
          assertEquals("Bolo", ped.getNome());
    }

    @Test
    public void excluir() throws SQLException, ClassNotFoundException {
          Pedido ped = new Pedido(4,"", "");
          ControlePedido contPed = new ControlePedido();
          ped = contPed.excluiPedido(ped);
          assertEquals(4, ped.getId());
    }

    @Test
    public void buscar() throws SQLException, ClassNotFoundException {
          Pedido ped = new Pedido(1,"", "");
          ControlePedido contPed = new ControlePedido();
          ped = contPed.buscaPedidoPorId(ped);
          assertEquals("Teste de Alteração", ped.getNome());
    }

    @Test
    public void alterar() throws SQLException, ClassNotFoundException {
          Pedido ped = new Pedido(1,"Teste de Alteração", "50");
          ControlePedido contPed = new ControlePedido();
          ped = contPed.alteraPedido(ped);
          assertEquals("Teste de Alteração", ped.getNome());
    }

    
}
